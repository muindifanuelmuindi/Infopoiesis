import pandas as pd
import numpy as np
import os
import re

# === PARAMETERS ===
INPUT_FILE = "core_periphery_influence_by_year.csv"
BASE_OUTPUT_DIR = os.path.join("outputs", "local", "country")
COLUMN = "Influence_Index"
ENTITY = "Name"
TIME = "Year"

# === CLEAN NAME FOR FILESYSTEM ===
def clean_name(name):
    return re.sub(r"[^\w\-]", "_", name.strip())

# === NORMALIZATION FUNCTION ===
def normalize_local(series):
    min_val = series.min()
    max_val = series.max()
    if min_val == max_val:
        return np.zeros_like(series)
    return 2 * (series - min_val) / (max_val - min_val) - 1

# === CLEAN .TXT WRITER ===
def write_clean_txt(filepath, values):
    with open(filepath, "w", newline="\n") as f:
        for v in values:
            f.write(f"{v:.6f}\n")  # fixed float precision, no trailing empty lines

# === LOAD DATA ===
df = pd.read_csv(INPUT_FILE)
df = df.dropna(subset=[ENTITY, TIME, COLUMN])
df[TIME] = df[TIME].astype(int)

# === LOOP OVER COUNTRIES ===
for name, group in df.groupby(ENTITY):
    group_sorted = group.sort_values(TIME)
    norm_values = normalize_local(group_sorted[COLUMN])
    safe_name = clean_name(name)

    # Create folder for this country
    country_dir = os.path.join(BASE_OUTPUT_DIR, safe_name)
    os.makedirs(country_dir, exist_ok=True)

    # File names
    base_filename = f"{COLUMN}_Country_{safe_name}_Local"
    csv_path = os.path.join(country_dir, f"{base_filename}.csv")
    txt_path = os.path.join(country_dir, f"{base_filename}.txt")

    # Save CSV
    pd.DataFrame({TIME: group_sorted[TIME].values, "Value": norm_values}).to_csv(csv_path, index=False)

    # Save TXT (clean format for Max)
    write_clean_txt(txt_path, norm_values)

print(f"✅ Local normalization complete. Clean files saved under: {BASE_OUTPUT_DIR}")