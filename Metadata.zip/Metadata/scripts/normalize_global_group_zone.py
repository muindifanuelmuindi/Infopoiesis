import pandas as pd
import numpy as np
import os
import re

# === CONFIG ===
GROUP_INPUT = "group_influence_index.csv"
ZONE_INPUT = "zone_influence_index.csv"
OUTPUT_DIR = os.path.join("outputs", "global")

# === HELPERS ===
def clean_name(name):
    return re.sub(r"[^\w\-]", "_", str(name).strip())

def normalize_global(series, global_min, global_max):
    if global_min == global_max:
        return np.zeros_like(series)
    return 2 * (series - global_min) / (global_max - global_min) - 1

def write_txt(filepath, values):
    with open(filepath, "w", newline="\n") as f:
        for v in values:
            f.write(f"{v:.6f}\n")

def normalize_and_save_global(df, entity_col, entity_label):
    global_min = df["Influence_Index"].min()
    global_max = df["Influence_Index"].max()

    for entity, group in df.groupby(entity_col):
        safe_name = clean_name(entity)
        sorted_group = group.sort_values("Year")
        norm_values = normalize_global(sorted_group["Influence_Index"], global_min, global_max)

        # Prepare output paths
        entity_dir = os.path.join(OUTPUT_DIR, entity_label, safe_name)
        os.makedirs(entity_dir, exist_ok=True)

        base_filename = f"InfluenceIndex_{entity_col}_{safe_name}_Global"
        csv_path = os.path.join(entity_dir, f"{base_filename}.csv")
        txt_path = os.path.join(entity_dir, f"{base_filename}.txt")

        # Save CSV
        pd.DataFrame({
            "Year": sorted_group["Year"],
            "Normalized_Influence_Index": norm_values
        }).to_csv(csv_path, index=False)

        # Save TXT
        write_txt(txt_path, norm_values)

# === LOAD AND NORMALIZE ===
group_df = pd.read_csv(GROUP_INPUT)
zone_df = pd.read_csv(ZONE_INPUT)

group_df["Year"] = group_df["Year"].astype(int)
zone_df["Year"] = zone_df["Year"].astype(int)

group_df["Influence_Index"] = pd.to_numeric(group_df["Influence_Index"], errors="coerce")
zone_df["Influence_Index"] = pd.to_numeric(zone_df["Influence_Index"], errors="coerce")

normalize_and_save_global(group_df, "Group", "group")
normalize_and_save_global(zone_df, "Zone", "zone")

print("✅ Global normalization complete for group and zone. Outputs saved under 'outputs/global/'")