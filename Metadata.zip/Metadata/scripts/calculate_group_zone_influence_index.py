import pandas as pd
import numpy as np

# === PARAMETERS ===
INPUT_FILE = "core_periphery_influence_by_year.csv"
OUTPUT_GROUP_CSV = "group_influence_index.csv"
OUTPUT_ZONE_CSV = "zone_influence_index.csv"

WEIGHTS = {
    "hdi": 0.35,
    "gdp_pc": 2.6e-6,
    "total_gdp": 1.7e-14,
    "intercept": -0.007
}

# === LOAD DATA ===
df = pd.read_csv(INPUT_FILE)
df = df.dropna(subset=["Year", "Group", "Zone", "Population", "HDI", "GDP_per_capita"])

df["Year"] = df["Year"].astype(int)

# === DERIVE population-weighted group/zone metrics ===
def compute_weighted_aggregates(df, by_col):
    results = []

    for (group, year), group_df in df.groupby([by_col, "Year"]):
        pop = group_df["Population"]
        hdi = group_df["HDI"]
        gdp_pc = group_df["GDP_per_capita"]

        pop_total = pop.sum()

        # Weighted averages
        hdi_avg = np.average(hdi, weights=pop)
        gdp_pc_avg = np.average(gdp_pc, weights=pop)

        # Total GDP = total pop × weighted gdp_pc
        total_gdp = pop_total * gdp_pc_avg

        # Influence Index formula
        influence = (
            WEIGHTS["hdi"] * hdi_avg +
            WEIGHTS["gdp_pc"] * gdp_pc_avg +
            WEIGHTS["total_gdp"] * total_gdp +
            WEIGHTS["intercept"]
        )

        results.append({
            by_col: group,
            "Year": year,
            "Weighted_HDI": hdi_avg,
            "Weighted_GDP_per_capita": gdp_pc_avg,
            "Total_Population": pop_total,
            "Total_GDP": total_gdp,
            "Influence_Index": influence
        })

    return pd.DataFrame(results)

# === PROCESS GROUPS ===
group_df = compute_weighted_aggregates(df, "Group")
group_df.to_csv(OUTPUT_GROUP_CSV, index=False)

# === PROCESS ZONES ===
zone_df = compute_weighted_aggregates(df, "Zone")
zone_df.to_csv(OUTPUT_ZONE_CSV, index=False)

print(f"✅ Group and zone-level influence indices saved as:\n- {OUTPUT_GROUP_CSV}\n- {OUTPUT_ZONE_CSV}")