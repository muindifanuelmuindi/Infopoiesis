import pandas as pd
import numpy as np
import os
import re

# === CONFIG ===
GROUP_INPUT = "group_influence_index.csv"
ZONE_INPUT = "zone_influence_index.csv"
OUTPUT_DIR = os.path.join("outputs", "perspective")

# === HELPERS ===
def clean_name(name):
    return re.sub(r"[^\w\-]", "_", str(name).strip())

def normalize_perspective(global_vals, local_min, local_max):
    normed = np.empty_like(global_vals)
    for i, val in enumerate(global_vals):
        if local_max == local_min:
            normed[i] = 0.0
        elif val >= local_max:
            normed[i] = 1.0
        elif val <= local_min:
            normed[i] = -1.0
        else:
            normed[i] = 2 * (val - local_min) / (local_max - local_min) - 1
    return normed

def write_txt(filepath, values):
    with open(filepath, "w", newline="\n") as f:
        for v in values:
            f.write(f"{v:.6f}\n")

def perspective_normalize(df, entity_col, entity_label):
    # Compute global average time series for this domain
    global_series = df.groupby("Year")["Influence_Index"].mean().reset_index()

    for entity, group in df.groupby(entity_col):
        safe_name = clean_name(entity)
        local_min = group["Influence_Index"].min()
        local_max = group["Influence_Index"].max()
        normed_vals = normalize_perspective(global_series["Influence_Index"].values, local_min, local_max)

        # Output structure
        entity_dir = os.path.join(OUTPUT_DIR, entity_label, safe_name)
        os.makedirs(entity_dir, exist_ok=True)

        base_filename = f"InfluenceIndex_{entity_col}_{safe_name}_Perspective"
        csv_path = os.path.join(entity_dir, f"{base_filename}.csv")
        txt_path = os.path.join(entity_dir, f"{base_filename}.txt")

        # Save files
        pd.DataFrame({
            "Year": global_series["Year"],
            "Normalized_Influence_Index": normed_vals
        }).to_csv(csv_path, index=False)

        write_txt(txt_path, normed_vals)

# === LOAD AND RUN ===
group_df = pd.read_csv(GROUP_INPUT)
zone_df = pd.read_csv(ZONE_INPUT)

group_df["Year"] = group_df["Year"].astype(int)
zone_df["Year"] = zone_df["Year"].astype(int)

group_df["Influence_Index"] = pd.to_numeric(group_df["Influence_Index"], errors="coerce")
zone_df["Influence_Index"] = pd.to_numeric(zone_df["Influence_Index"], errors="coerce")

perspective_normalize(group_df, "Group", "group")
perspective_normalize(zone_df, "Zone", "zone")

print("✅ Perspective normalization complete for group and zone. Outputs saved under 'outputs/perspective/'")