import pandas as pd
import numpy as np
import os
import re

# === CONFIG ===
INPUT_FILE = "core_periphery_influence_by_year.csv"
OUTPUT_DIR = os.path.join("outputs", "variance_global")

# === HELPERS ===
def clean_name(name):
    return re.sub(r"[^\w\-]", "_", str(name).strip())

def normalize_global(series, global_min, global_max):
    if global_min == global_max:
        return np.zeros_like(series)
    return 2 * (series - global_min) / (global_max - global_min) - 1

def write_txt(path, values):
    with open(path, "w", newline="\n") as f:
        for v in values:
            f.write(f"{v:.6f}\n")

def compute_and_save_variance_global(df, domain, label):
    # Compute variance (std dev) per year per entity
    grouped = df.groupby(["Year", domain])["Influence_Index"].std().reset_index()

    # Global min and max across all entities/years
    global_min = grouped["Influence_Index"].min()
    global_max = grouped["Influence_Index"].max()

    for entity, group in grouped.groupby(domain):
        safe_name = clean_name(entity)
        years = group["Year"].values
        std_series = group["Influence_Index"].values
        norm_std = normalize_global(std_series, global_min, global_max)

        # Save to disk
        entity_dir = os.path.join(OUTPUT_DIR, label, safe_name)
        os.makedirs(entity_dir, exist_ok=True)

        base = f"InfluenceIndex_{domain}_{safe_name}_Variance"
        pd.DataFrame({"Year": years, "Normalized_Influence_Index": norm_std}).to_csv(
            os.path.join(entity_dir, f"{base}.csv"), index=False
        )
        write_txt(os.path.join(entity_dir, f"{base}.txt"), norm_std)

# === LOAD DATA ===
df = pd.read_csv(INPUT_FILE)
df = df.dropna(subset=["Year", "Group", "Zone", "Influence_Index"])
df["Year"] = df["Year"].astype(int)
df["Influence_Index"] = pd.to_numeric(df["Influence_Index"], errors="coerce")

# === RUN GLOBAL VARIANCE NORMALIZATION ===
compute_and_save_variance_global(df, "Group", "group")
compute_and_save_variance_global(df, "Zone", "zone")

print("✅ Global-normalized variance (std dev) complete for group and zone.")