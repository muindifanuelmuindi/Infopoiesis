import pandas as pd
import numpy as np
import os
import re

# === CONFIG ===
RAW_INPUT = "core_periphery_influence_by_year.csv"
GROUP_INPUT = "group_influence_index.csv"
ZONE_INPUT = "zone_influence_index.csv"
OUTPUT_BASE = os.path.join("outputs", "perspective_on_group_zone")

# === HELPERS ===
def clean_name(name):
    return re.sub(r"[^\w\-]", "_", str(name).strip())

def perspective_rescale(series, local_min, local_max):
    result = []
    for val in series:
        if local_max == local_min:
            result.append(0.0)
        elif val >= local_max:
            result.append(1.0)
        elif val <= local_min:
            result.append(-1.0)
        else:
            norm = 2 * (val - local_min) / (local_max - local_min) - 1
            result.append(norm)
    return result

def write_txt(path, values):
    with open(path, "w", newline="\n") as f:
        for val in values:
            f.write(f"{val:.6f}\n")

def write_outputs(entity_name, label, years, values):
    safe_name = clean_name(entity_name)
    folder = os.path.join(OUTPUT_BASE, safe_name)
    os.makedirs(folder, exist_ok=True)

    base = f"InfluenceIndex_{label}Perspective_{safe_name}"
    pd.DataFrame({"Year": years, "Normalized_Influence_Index": values}).to_csv(
        os.path.join(folder, f"{base}.csv"), index=False
    )
    write_txt(os.path.join(folder, f"{base}.txt"), values)

# === LOAD DATA ===
raw_df = pd.read_csv(RAW_INPUT)
group_df = pd.read_csv(GROUP_INPUT)
zone_df = pd.read_csv(ZONE_INPUT)

raw_df = raw_df.dropna(subset=["Name", "Group", "Zone", "Year", "Influence_Index"])
raw_df["Year"] = raw_df["Year"].astype(int)
raw_df["Influence_Index"] = pd.to_numeric(raw_df["Influence_Index"], errors="coerce")

group_df["Year"] = group_df["Year"].astype(int)
zone_df["Year"] = zone_df["Year"].astype(int)
group_df["Influence_Index"] = pd.to_numeric(group_df["Influence_Index"], errors="coerce")
zone_df["Influence_Index"] = pd.to_numeric(zone_df["Influence_Index"], errors="coerce")

# === MAIN PROCESSING ===
for country, group in raw_df.groupby("Name"):
    group_name = group["Group"].iloc[0]
    zone_name = group["Zone"].iloc[0]

    # Country min/max
    local_min = group["Influence_Index"].min()
    local_max = group["Influence_Index"].max()

    # Group series
    group_series = group_df[group_df["Group"] == group_name].sort_values("Year")
    g_years = group_series["Year"].values
    g_values = group_series["Influence_Index"].values
    norm_g = perspective_rescale(g_values, local_min, local_max)
    write_outputs(country, "Group", g_years, norm_g)

    # Zone series
    zone_series = zone_df[zone_df["Zone"] == zone_name].sort_values("Year")
    z_years = zone_series["Year"].values
    z_values = zone_series["Influence_Index"].values
    norm_z = perspective_rescale(z_values, local_min, local_max)
    write_outputs(country, "Zone", z_years, norm_z)

print("✅ Country perspective on group/zone influence index complete.")