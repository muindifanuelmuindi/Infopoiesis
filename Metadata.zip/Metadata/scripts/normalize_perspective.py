import pandas as pd
import numpy as np
import os
import re

# === PARAMETERS ===
INPUT_FILE = "core_periphery_influence_by_year.csv"
BASE_OUTPUT_DIR = os.path.join("outputs", "perspective", "country")
COLUMN = "Influence_Index"
ENTITY = "Name"
TIME = "Year"

def clean_name(name):
    return re.sub(r"[^\w\-]", "_", name.strip())

def write_clean_txt(filepath, values):
    with open(filepath, "w", newline="\n") as f:
        for v in values:
            f.write(f"{v:.6f}\n")

def normalize_perspective_clipped(global_series, local_min, local_max):
    normed = np.empty_like(global_series)
    for i, val in enumerate(global_series):
        if local_max == local_min:
            normed[i] = 0.0
        elif val >= local_max:
            normed[i] = 1.0
        elif val <= local_min:
            normed[i] = -1.0
        else:
            normed[i] = 2 * (val - local_min) / (local_max - local_min) - 1
    return normed

# === LOAD DATA ===
df = pd.read_csv(INPUT_FILE)
df = df.dropna(subset=[ENTITY, TIME, COLUMN])
df[TIME] = df[TIME].astype(int)

# Global average series: one value per year
global_series = df.groupby(TIME)[COLUMN].mean().reset_index()

# === LOOP OVER COUNTRIES ===
for name, group in df.groupby(ENTITY):
    safe_name = clean_name(name)
    local_min = group[COLUMN].min()
    local_max = group[COLUMN].max()

    # Perspective normalization: global data as viewed from local range
    norm_vals = normalize_perspective_clipped(global_series[COLUMN].values, local_min, local_max)

    # Output directory
    country_dir = os.path.join(BASE_OUTPUT_DIR, safe_name)
    os.makedirs(country_dir, exist_ok=True)

    # Filenames
    base_filename = f"{COLUMN}_Country_{safe_name}_Perspective"
    csv_path = os.path.join(country_dir, f"{base_filename}.csv")
    txt_path = os.path.join(country_dir, f"{base_filename}.txt")

    # Save files
    pd.DataFrame({TIME: global_series[TIME], "Value": norm_vals}).to_csv(csv_path, index=False)
    write_clean_txt(txt_path, norm_vals)

print(f"✅ Perspective normalization complete (clipped to [-1,1]). Output in: {BASE_OUTPUT_DIR}")